using Microsoft.EntityFrameworkCore;
using Stacklt_Odoo.Models;

namespace Stacklt_Odoo.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Answer> Answers { get; set; }
        public DbSet<Tag> Tags { get; set; }
        public DbSet<QuestionTag> QuestionTags { get; set; }
        public DbSet<Vote> Votes { get; set; }
        public DbSet<Notification> Notifications { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure table names to match your database schema
            modelBuilder.Entity<User>().ToTable("St_Users");
            modelBuilder.Entity<Question>().ToTable("St_Questions");
            modelBuilder.Entity<Answer>().ToTable("St_Answers");
            modelBuilder.Entity<Tag>().ToTable("St_Tags");
            modelBuilder.Entity<QuestionTag>().ToTable("St_QuestionTags");
            modelBuilder.Entity<Vote>().ToTable("St_Votes");
            modelBuilder.Entity<Notification>().ToTable("St_Notifications");

            // Configure composite primary key for QuestionTag
            modelBuilder.Entity<QuestionTag>()
                .HasKey(qt => new { qt.QuestionId, qt.TagId });

            // Configure unique constraint for Vote (one vote per user per answer)
            modelBuilder.Entity<Vote>()
                .HasIndex(v => new { v.AnswerId, v.UserId })
                .IsUnique();

            // Configure relationships
            modelBuilder.Entity<Question>()
                .HasOne(q => q.User)
                .WithMany(u => u.Questions)
                .HasForeignKey(q => q.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Answer>()
                .HasOne(a => a.Question)
                .WithMany(q => q.Answers)
                .HasForeignKey(a => a.QuestionId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Answer>()
                .HasOne(a => a.User)
                .WithMany(u => u.Answers)
                .HasForeignKey(a => a.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Vote>()
                .HasOne(v => v.Answer)
                .WithMany(a => a.Votes)
                .HasForeignKey(v => v.AnswerId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Vote>()
                .HasOne(v => v.User)
                .WithMany(u => u.Votes)
                .HasForeignKey(v => v.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany(u => u.Notifications)
                .HasForeignKey(n => n.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure QuestionTag relationships
            modelBuilder.Entity<QuestionTag>()
                .HasOne(qt => qt.Question)
                .WithMany(q => q.QuestionTags)
                .HasForeignKey(qt => qt.QuestionId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<QuestionTag>()
                .HasOne(qt => qt.Tag)
                .WithMany(t => t.QuestionTags)
                .HasForeignKey(qt => qt.TagId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure accepted answer relationship
            modelBuilder.Entity<Question>()
                .HasOne(q => q.AcceptedAnswer)
                .WithMany(a => a.QuestionsWhereAccepted)
                .HasForeignKey(q => q.AcceptedAnswerId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
} 